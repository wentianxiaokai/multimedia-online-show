#iPhoto-MUFENG
Mufeng 早期开源主题，放至 Coding.net 作备份之用。 
原作者链接：http://mufeng.me 
主题介绍地址：http://www.mywpku.com/iphoto.html